export const environment = {
    production: true,
    backendURL: "http://actapp.tk:3000"
};
