use Actapp;
db.createCollection( "admin" );
db.createCollection( "player" );
db.createCollection( "team" );
db.createCollection( "competition" );
db.createCollection( "comp_player_stats" );
db.createCollection( "comp_team_stats" );
db.createCollection( "comp_game" );
db.createCollection( "comp_playoff_round" );
db.createCollection( "comp_event" );


 
