#!/bin/bash

sudo apt-get install -y nodejs npm mongodb
sudo npm install -g @angular/cli

#unzip package

cd backend
npm install --save 
cd ..
cd frontend 
npm install --save
cd ..

sh /opt/mongodb/mongodb-linux-x86_64-4.0.10/bin/mongodserver.sh
mongo --eval "use admin; db.createUser( { user: 'administrator',
          pwd: 'trabajoFinGrado',
          roles: [ 'userAdminAnyDatabase',
                   'dbAdminAnyDatabase',
                   'readWriteAnyDatabase'
] } );"
mongo -u administrator -p trabajoFinGrado < init_mongo.js

node --inspect "backend/server.js"
cd frontend
npm run start
cd ..

